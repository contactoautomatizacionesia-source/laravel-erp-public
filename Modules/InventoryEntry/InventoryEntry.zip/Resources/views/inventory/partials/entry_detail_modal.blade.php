<dialog class="modal fade" id="entryDetailModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="ti-clipboard mr-2"></i>
                    {{ __('inventoryentry::inventory.entry_detail') }}
                </h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">

                {{-- Info del lote --}}
                <div class="mb-20">
                    <h6 class="mb-10"><i class="ti-tag mr-1"></i> {{ __('inventoryentry::inventory.lot_info') }}</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.lot_number') }}</span>
                                <strong>{{ $entry->lot->lot_number }}</strong>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.col_status') }}</span>
                                <span class="{{ $statusBadge['class'] }}">{{ $statusBadge['label'] }}</span>
                            </div>
                        </div>
                        @if($entry->lot->manufacture_date)
                        <div class="col-md-6">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.manufacture_date') }}</span>
                                <strong>{{ $entry->lot->manufacture_date->format('Y-m-d') }}</strong>
                            </div>
                        </div>
                        @endif
                        @if($entry->lot->expiration_date)
                        <div class="col-md-6">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.expiration_date') }}</span>
                                <strong>{{ $entry->lot->expiration_date->format('Y-m-d') }}</strong>
                            </div>
                        </div>
                        @endif
                        @if($entry->lot->supplier)
                        <div class="col-md-6">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.supplier') }}</span>
                                <strong>{{ $entry->lot->supplier }}</strong>
                            </div>
                        </div>
                        @endif
                        @if($entry->lot->notes)
                        <div class="col-md-12">
                            <div class="d-flex flex-column mb-10">
                                <span class="d-block text-muted" style="font-size:.82rem;">{{ __('inventoryentry::inventory.notes') }}</span>
                                <span>{{ $entry->lot->notes }}</span>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>

                <hr>

                {{-- Historial de ingresos del lote --}}
                <div>
                    <h6 class="mb-10"><i class="ti-list mr-1"></i> {{ __('inventoryentry::inventory.entries_history') }}</h6>
                    <div class="table-responsive ign-scrollbar">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>{{ __('inventoryentry::inventory.col_product') }}</th>
                                    <th>{{ __('inventoryentry::inventory.col_sku') }}</th>
                                    <th>{{ __('inventoryentry::inventory.col_quantity') }}</th>
                                    <th>{{ __('inventoryentry::inventory.unit_cost') }}</th>
                                    <th>{{ __('inventoryentry::inventory.location') }}</th>
                                    <th>{{ __('inventoryentry::inventory.col_created_by') }}</th>
                                    <th>{{ __('inventoryentry::inventory.col_created_at') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($entry->lot->entries as $lotEntry)
                                @php
                                    $productName = '';
                                    if ($lotEntry->productSku?->product) {
                                        $name    = $lotEntry->productSku->product->product_name;
                                        $decoded = json_decode($name, true);
                                        $productName = is_array($decoded)
                                            ? ($decoded[app()->getLocale()] ?? reset($decoded) ?? $name)
                                            : $name;
                                    }
                                    $skuLabel = $lotEntry->productSku?->track_sku ?: ($lotEntry->productSku?->sku ?: "SKU #{$lotEntry->product_sku_id}");
                                    $isCurrentEntry = $lotEntry->id === $entry->id;
                                @endphp
                                <tr @if($isCurrentEntry) style="background:rgba(var(--base_color_rgb),.06);" @endif>
                                    <td>{{ $productName ?: 'N/A' }}</td>
                                    <td>
                                        @if($lotEntry->productSku?->track_sku)
                                            <span class="badge_5">{{ $lotEntry->productSku->track_sku }}</span>
                                        @else
                                            {{ $skuLabel }}
                                        @endif
                                    </td>
                                    <td><strong>{{ $lotEntry->quantity }}</strong></td>
                                    <td>{{ $lotEntry->unit_cost ? number_format($lotEntry->unit_cost, 2) : '—' }}</td>
                                    <td>{{ $lotEntry->warehouse_location }}</td>
                                    <td>
                                        @if($lotEntry->createdBy)
                                            {{ trim($lotEntry->createdBy->first_name . ' ' . $lotEntry->createdBy->last_name) }}
                                        @else
                                            N/A
                                        @endif
                                    </td>
                                    <td>
                                        <span title="{{ $lotEntry->created_at->format('Y-m-d H:i') }}">
                                            {{ $lotEntry->created_at->diffForHumans() }}
                                        </span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn-toolkit btn-secondary-outline" data-dismiss="modal">
                    {{ __('common.close') }}
                </button>
            </div>
        </div>
    </div>
</dialog>
