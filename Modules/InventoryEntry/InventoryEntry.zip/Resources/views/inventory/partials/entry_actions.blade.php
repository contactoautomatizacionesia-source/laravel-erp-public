<div class="dropdown CRM_dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown">
        {{ __('common.select') }}
    </button>
    <div class="dropdown-menu dropdown-menu-right">
        <a class="dropdown-item view_entry_detail" data-id="{{ $row->id }}" style="cursor:pointer;">
            {{ __('inventoryentry::inventory.detail_view') }}
        </a>
    </div>
</div>
