@extends('backEnd.master')

@section('mainContent')
<section class="admin-visitor-area up_st_admin_visitor">
    <div class="container-fluid white_box_30px mb_30">
        <div class="row justify-content-center">

            {{-- Botón acción --}}
            <div class="col-12 mb-10">
                <div class="box_header_right">
                    <div class="pos_tab_btn justify-content-end">
                        <ul class="nav ign-scrollbar flex-nowrap w-100 overflow-auto pb-2">
                            <li class="nav-item">
                                <a href="{{ route('inventory_entry.create') }}" class="nav-link action">
                                    <i class="fas fa-plus"></i> {{ __('inventoryentry::inventory.new_entry') }}
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            {{-- Título --}}
            <div class="col-lg-12">
                <div class="box_header common_table_header">
                    <div class="main-title d-md-flex">
                        <h3 class="mb-0 mr-30 mb_xs_15px mb_sm_20px">
                            {{ __('inventoryentry::inventory.inventory_entry_management') }}
                        </h3>
                    </div>
                </div>

                {{-- Filtros --}}
                <div class="row mb-15">
                    <div class="col-md-3 mb-10">
                        <input type="text" id="filter_product" class="primary_input_field"
                               placeholder="{{ __('inventoryentry::inventory.filter_product') }}">
                    </div>
                    <div class="col-md-2 mb-10">
                        <input type="text" id="filter_lot" class="primary_input_field"
                               placeholder="{{ __('inventoryentry::inventory.filter_lot') }}">
                    </div>
                    <div class="col-md-2 mb-10">
                        <select id="filter_status" class="primary_input_select">
                            <option value="">{{ __('inventoryentry::inventory.filter_status') }}</option>
                            <option value="vigente">{{ __('inventoryentry::inventory.status_valid') }}</option>
                            <option value="por_vencer">{{ __('inventoryentry::inventory.status_expiring') }}</option>
                            <option value="vencido">{{ __('inventoryentry::inventory.status_expired') }}</option>
                        </select>
                    </div>
                    <div class="col-md-2 mb-10">
                        <input type="date" id="filter_exp_from" class="primary_input_field"
                               placeholder="{{ __('inventoryentry::inventory.filter_date_from') }}">
                    </div>
                    <div class="col-md-2 mb-10">
                        <input type="date" id="filter_exp_to" class="primary_input_field"
                               placeholder="{{ __('inventoryentry::inventory.filter_date_to') }}">
                    </div>
                    <div class="col-md-1 mb-10 d-flex align-items-center">
                        <button id="btn_clear_filters" class="btn-toolkit btn-secondary-outline w-100" type="button">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                {{-- Tabla --}}
                <div class="QA_section QA_list_admin_dashboard_inventory">
                    <div class="QA_table">
                        <div class="table-responsive ign-scrollbar">
                            <table class="table" id="inventoryEntryTable">
                                <thead>
                                    <tr>
                                        <th>{{ __('common.sl') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_product') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_sku') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_lot') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_manufacture') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_expiration') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_quantity') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_status') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_created_by') }}</th>
                                        <th>{{ __('inventoryentry::inventory.col_created_at') }}</th>
                                        <th>{{ __('common.action') }}</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<div id="entryDetailContainer"></div>
@endsection

@push('scripts')
<script>
$(document).ready(function () {

    let ajaxUrl = "{{ route('inventory_entry.get-data') }}";

    let columns = [
        { data: 'DT_RowIndex',     name: 'id',              render: d => numbertrans(d) },
        { data: 'product_name',    name: 'product_name',    searchable: false },
        { data: 'sku_variant',     name: 'sku_variant',     searchable: false, orderable: false },
        { data: 'lot_number',      name: 'lot.lot_number',  searchable: false },
        { data: 'manufacture_date',name: 'manufacture_date',searchable: false, orderable: false },
        { data: 'expiration_date', name: 'expiration_date', searchable: false, orderable: false },
        { data: 'quantity',        name: 'quantity',        render: d => numbertrans(d) },
        { data: 'status_badge',    name: 'status_badge',    searchable: false, orderable: false },
        { data: 'created_by_name', name: 'created_by_name', searchable: false, orderable: false },
        { data: 'entry_date',      name: 'created_at',      searchable: false },
        { data: 'actions',         name: 'actions',         orderable: false, searchable: false },
    ];

    let table = initGlobalDataTable('#inventoryEntryTable', ajaxUrl, columns, {
        stateSave: false,
        ajax: {
            url: ajaxUrl,
            data: function (d) {
                d.product_filter = $('#filter_product').val();
                d.lot_filter     = $('#filter_lot').val();
                d.status_filter  = $('#filter_status').val();
                d.exp_from       = $('#filter_exp_from').val();
                d.exp_to         = $('#filter_exp_to').val();
            }
        }
    });

    // Aplicar filtros al escribir / cambiar
    let filterDelay;
    $('#filter_product, #filter_lot').on('keyup', function () {
        clearTimeout(filterDelay);
        filterDelay = setTimeout(function () { table.ajax.reload(); }, 400);
    });
    $('#filter_status, #filter_exp_from, #filter_exp_to').on('change', function () {
        table.ajax.reload();
    });

    // Limpiar filtros
    $('#btn_clear_filters').on('click', function () {
        $('#filter_product, #filter_lot, #filter_exp_from, #filter_exp_to').val('');
        $('#filter_status').val('');
        table.ajax.reload();
    });

    // Ver detalle
    $(document).on('click', '.view_entry_detail', function () {
        let id  = $(this).data('id');
        let url = "{{ route('inventory_entry.detail', ['id' => ':id']) }}".replace(':id', id);
        $('#pre-loader').removeClass('d-none');

        $.get(url, function (html) {
            $('#entryDetailContainer').html(html);
            $('#entryDetailModal').modal('show');
            $('#pre-loader').addClass('d-none');
        }).fail(function () {
            $('#pre-loader').addClass('d-none');
            toastr.error("{{ __('common.something_wrong') }}");
        });
    });

    $(window).on('load pageshow', function () {
        $('#pre-loader').addClass('d-none');
    });
});
</script>
@endpush
