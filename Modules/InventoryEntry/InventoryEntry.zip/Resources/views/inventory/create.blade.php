@extends('backEnd.master')

@section('mainContent')
<section class="admin-visitor-area up_st_admin_visitor">
    <div class="container-fluid white_box_30px mb_30">

        <div class="row mb-20">
            <div class="col-md-12">
                <div class="d-flex align-items-center">
                    <x-backEnd.back-button :text="false" />
                    <h3 class="mb-0 ml-3">{{ __('inventoryentry::inventory.new_entry') }}</h3>
                </div>
            </div>
        </div>

        <div class="row">
            {{-- Buscador de producto --}}
            <div class="col-md-12 mb-20">
                <div class="white_box_30px">
                    <div class="row align-items-end">
                        <div class="col-md-6">
                            <label class="primary_input_label" for="product_search">
                                {{ __('inventoryentry::inventory.product') }} <span class="text-danger">*</span>
                            </label>
                            <select id="product_search" class="primary_input_select w-100">
                                <option value="">{{ __('inventoryentry::inventory.product_hint') }}</option>
                            </select>
                        </div>
                        <div class="col-md-6" id="product_info_col" style="display:none;">
                            <div id="product_info_card" class="d-flex align-items-center">
                                <img id="product_thumb" src="" alt="" class="mr-3 rounded"
                                     style="width:48px;height:48px;object-fit:cover;border:1px solid #eee;">
                                <div>
                                    <strong id="product_name_label" class="d-block"></strong>
                                    <small id="product_type_label" class="text-muted"></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Tabla de SKUs (se muestra tras seleccionar producto) --}}
            <div class="col-md-12" id="skus_section" style="display:none;">
                <div class="white_box_30px">
                    <h5 class="mb-15">
                        <i class="ti-package mr-2"></i>
                        {{ __('inventoryentry::inventory.new_entry') }} — <span id="skus_product_name"></span>
                    </h5>

                    <div class="table-responsive ign-scrollbar">
                        <table class="table sku_entry_table" id="skuEntryTable">
                            <thead>
                                <tr>
                                    <th>{{ __('inventoryentry::inventory.variant') }}</th>
                                    <th>{{ __('inventoryentry::inventory.col_quantity') }} <span class="text-muted" style="font-size:.75rem;">(actual)</span></th>
                                    <th>{{ __('inventoryentry::inventory.lot_number') }} <span class="text-danger">*</span></th>
                                    <th>{{ __('inventoryentry::inventory.manufacture_date') }}</th>
                                    <th>{{ __('inventoryentry::inventory.expiration_date') }}</th>
                                    <th>{{ __('inventoryentry::inventory.quantity') }} <span class="text-danger">*</span></th>
                                    <th>{{ __('inventoryentry::inventory.unit_cost') }}</th>
                                    <th>{{ __('inventoryentry::inventory.location') }}</th>
                                </tr>
                            </thead>
                            <tbody id="skuEntryBody">
                                {{-- Filas generadas por JS --}}
                            </tbody>
                        </table>
                    </div>

                    {{-- Campos comunes opcionales (proveedor / notas) --}}
                    <div class="row mt-20">
                        <div class="col-md-6">
                            <label class="primary_input_label" for="common_supplier">
                                {{ __('inventoryentry::inventory.supplier') }}
                            </label>
                            <input type="text" id="common_supplier" class="primary_input_field"
                                   placeholder="{{ __('inventoryentry::inventory.supplier') }}">
                        </div>
                        <div class="col-md-6">
                            <label class="primary_input_label" for="common_notes">
                                {{ __('inventoryentry::inventory.notes') }}
                            </label>
                            <input type="text" id="common_notes" class="primary_input_field"
                                   placeholder="{{ __('inventoryentry::inventory.notes') }}">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-20">
                        <button type="button" id="btn_save_entries" class="btn-toolkit btn-primary">
                            <i class="fas fa-save mr-1"></i> {{ __('inventoryentry::inventory.confirm_save') }}
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
@endsection

@push('scripts')
<script>
$(document).ready(function () {

    const storeUrl   = "{{ route('inventory_entry.store') }}";
    const findLotUrl = "{{ route('inventory_entry.lots.find') }}";
    const searchUrl  = "{{ route('inventory_entry.products.search') }}";
    const skusUrl    = "{{ route('inventory_entry.products.skus', ['productId' => ':id']) }}";

    const labelValid    = "{{ __('inventoryentry::inventory.status_valid') }}";
    const labelExpiring = "{{ __('inventoryentry::inventory.status_expiring') }}";
    const labelExpired  = "{{ __('inventoryentry::inventory.status_expired') }}";
    const labelLocation = "{{ __('inventoryentry::inventory.location_default') }}";
    const labelLotFound = "{{ __('inventoryentry::inventory.lot_found') }}";
    const labelLotNew   = "{{ __('inventoryentry::inventory.lot_new') }}";

    // ─── Select2 búsqueda de producto ────────────────────────────
    $('#product_search').select2({
        placeholder: "{{ __('inventoryentry::inventory.product_hint') }}",
        minimumInputLength: 2,
        ajax: {
            url: searchUrl,
            dataType: 'json',
            delay: 300,
            data: params => ({ q: params.term }),
            processResults: data => ({ results: data.results }),
        },
        width: '100%',
    });

    $('#product_search').on('select2:select', function (e) {
        let product = e.params.data;
        renderProductInfo(product);
        loadAndRenderSkus(product.id);
    });

    function renderProductInfo(product) {
        $('#product_name_label').text(product.text);
        $('#product_type_label').text(product.product_type == 1 ? 'Producto simple' : 'Producto con variantes');
        if (product.thumb) {
            $('#product_thumb').attr('src', product.thumb).show();
        } else {
            $('#product_thumb').hide();
        }
        $('#product_info_col').show();
        $('#skus_product_name').text(product.text);
    }

    // ─── Cargar SKUs y renderizar tabla ──────────────────────────
    function loadAndRenderSkus(productId) {
        let url = skusUrl.replace(':id', productId);
        $('#pre-loader').removeClass('d-none');

        $.get(url, function (data) {
            renderSkuRows(data.skus);
            $('#skus_section').show();
            $('#pre-loader').addClass('d-none');
        }).fail(function () {
            $('#pre-loader').addClass('d-none');
            toastr.error("{{ __('common.something_wrong') }}");
        });
    }

    function renderSkuRows(skus) {
        let $body = $('#skuEntryBody').empty();

        skus.forEach(function (sku, idx) {
            let row = `
            <tr class="sku-entry-row" data-sku-id="${sku.id}">
                <td class="align-middle">
                    <strong>${sku.text}</strong>
                    <small class="d-block text-muted">SKU actual: ${sku.product_stock}</small>
                </td>
                <td class="align-middle">
                    <span class="font-weight-bold current-stock-badge">${sku.product_stock}</span>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <input type="text"
                               class="primary_input_field lot-number-input"
                               placeholder="{{ __('inventoryentry::inventory.lot_number_hint') }}"
                               autocomplete="off"
                               data-idx="${idx}">
                        <span class="lot-indicator ml-1" style="min-width:20px;"></span>
                    </div>
                    <small class="lot-hint text-muted d-block mt-1" style="font-size:.75rem;"></small>
                </td>
                <td>
                    <input type="date" class="primary_input_field manufacture-date-input" data-idx="${idx}">
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <input type="date" class="primary_input_field expiration-date-input" data-idx="${idx}">
                        <span class="exp-badge ml-1" style="min-width:60px;"></span>
                    </div>
                </td>
                <td>
                    <input type="number" class="primary_input_field quantity-input" min="0.01" step="0.01"
                           placeholder="0" data-idx="${idx}">
                </td>
                <td>
                    <input type="number" class="primary_input_field unit-cost-input" min="0" step="0.01"
                           placeholder="{{ __('inventoryentry::inventory.unit_cost_hint') }}" data-idx="${idx}">
                </td>
                <td>
                    <input type="text" class="primary_input_field location-input"
                           value="${labelLocation}" data-idx="${idx}">
                </td>
            </tr>`;
            $body.append(row);
        });
    }

    // ─── Badge de vencimiento en tiempo real por fila ─────────────
    $(document).on('change', '.expiration-date-input', function () {
        let $badge = $(this).closest('td').find('.exp-badge');
        let val    = $(this).val();
        if (!val) { $badge.html(''); return; }

        let today = new Date(); today.setHours(0,0,0,0);
        let exp   = new Date(val);
        let diff  = Math.ceil((exp - today) / 86400000);

        let cls, label;
        if (diff < 0)       { cls = 'badge_2'; label = labelExpired; }
        else if (diff <= 30){ cls = 'badge_3'; label = labelExpiring; }
        else                { cls = 'badge_1'; label = labelValid; }

        $badge.html(`<span class="${cls}" style="white-space:nowrap;">${label}</span>`);
    });

    // ─── Búsqueda de lote existente por fila ─────────────────────
    let lotTimers = {};
    $(document).on('keyup', '.lot-number-input', function () {
        let $row      = $(this).closest('tr');
        let $hint     = $row.find('.lot-hint');
        let $indicator= $row.find('.lot-indicator');
        let val       = $(this).val().trim();
        let idx       = $(this).data('idx');

        clearTimeout(lotTimers[idx]);
        if (val.length < 2) { $hint.text(''); $indicator.html(''); return; }

        lotTimers[idx] = setTimeout(function () {
            $.get(findLotUrl, { lot_number: val }, function (data) {
                if (data.found) {
                    $row.find('.manufacture-date-input').val(data.manufacture_date || '');
                    $row.find('.expiration-date-input').val(data.expiration_date || '').trigger('change');
                    $hint.html(`<span class="text-success"><i class="fas fa-check-circle"></i> ${labelLotFound}</span>`);
                    $indicator.html('<i class="fas fa-link text-success"></i>');
                } else {
                    $hint.html(`<span class="text-muted"><i class="fas fa-plus-circle"></i> ${labelLotNew}</span>`);
                    $indicator.html('');
                }
            });
        }, 500);
    });

    // ─── Guardar ──────────────────────────────────────────────────
    $('#btn_save_entries').on('click', function () {
        let entries = [];
        let hasError = false;

        $('#skuEntryBody .sku-entry-row').each(function () {
            let skuId    = $(this).data('sku-id');
            let lotNum   = $(this).find('.lot-number-input').val().trim();
            let qty      = $(this).find('.quantity-input').val();

            // Solo procesar filas con al menos lote y cantidad
            if (!lotNum && !qty) return; // fila vacía → omitir

            if (!lotNum) {
                toastr.warning(`{{ __('inventoryentry::inventory.lot_number') }}: campo requerido en SKU ${skuId}.`);
                hasError = true; return false;
            }
            if (!qty || parseFloat(qty) <= 0) {
                toastr.warning(`{{ __('inventoryentry::inventory.quantity') }}: debe ser mayor a 0 en SKU ${skuId}.`);
                hasError = true; return false;
            }

            entries.push({
                product_sku_id:     skuId,
                lot_number:         lotNum,
                manufacture_date:   $(this).find('.manufacture-date-input').val() || null,
                expiration_date:    $(this).find('.expiration-date-input').val() || null,
                quantity:           qty,
                unit_cost:          $(this).find('.unit-cost-input').val() || null,
                warehouse_location: $(this).find('.location-input').val() || labelLocation,
                supplier:           $('#common_supplier').val() || null,
                notes:              $('#common_notes').val() || null,
            });
        });

        if (hasError) return;

        if (entries.length === 0) {
            toastr.warning("{{ __('inventoryentry::inventory.no_entries_to_save') }}");
            return;
        }

        let $btn = $(this).prop('disabled', true)
                          .html('<i class="fas fa-spinner fa-spin mr-1"></i> Guardando...');

        $.post(storeUrl, {
            _token:  "{{ csrf_token() }}",
            entries: entries,
        }, function (response) {
            if (response.success) {
                toastr.success(response.message);
                setTimeout(function () {
                    window.location.href = "{{ route('inventory_entry.index') }}";
                }, 1200);
            } else {
                toastr.error(response.message || "{{ __('common.something_wrong') }}");
                $btn.prop('disabled', false)
                    .html('<i class="fas fa-save mr-1"></i> {{ __("inventoryentry::inventory.confirm_save") }}');
            }
        }).fail(function (xhr) {
            let errors = xhr.responseJSON?.errors;
            if (errors) {
                Object.values(errors).forEach(msgs => msgs.forEach(m => toastr.error(m)));
            } else {
                toastr.error(xhr.responseJSON?.message || "{{ __('common.something_wrong') }}");
            }
            $btn.prop('disabled', false)
                .html('<i class="fas fa-save mr-1"></i> {{ __("inventoryentry::inventory.confirm_save") }}');
        });
    });

    $(window).on('load pageshow', function () {
        $('#pre-loader').addClass('d-none');
    });
});
</script>
@endpush
