<?php

return [
    // Menú
    'menu_inventory_entry' => 'Ingresos de Inventario',

    // Títulos generales
    'inventory_entry_management' => 'Gestión de Ingresos de Inventario',
    'new_entry'                  => 'Nuevo Ingreso',
    'entry_detail'               => 'Detalle de Ingreso',

    // Campos del formulario
    'product'          => 'Producto',
    'product_hint'     => 'Buscar producto por nombre o SKU',
    'variant'          => 'Variante / SKU',
    'variant_hint'     => 'Seleccionar variante',
    'lot_number'       => 'Número de Lote',
    'lot_number_hint'  => 'Ingrese o busque un número de lote',
    'manufacture_date' => 'Fecha de Fabricación',
    'expiration_date'  => 'Fecha de Vencimiento',
    'quantity'         => 'Cantidad',
    'location'         => 'Ubicación en Bodega',
    'location_default' => 'Principal',
    'supplier'         => 'Proveedor / Origen del Lote',
    'unit_cost'        => 'Precio de Costo Unitario',
    'unit_cost_hint'   => 'Opcional — solo de referencia',
    'notes'            => 'Notas u Observaciones',

    // Columnas tabla
    'col_product'      => 'Producto',
    'col_sku'          => 'SKU / Variante',
    'col_lot'          => 'Lote',
    'col_manufacture'  => 'F. Fabricación',
    'col_expiration'   => 'F. Vencimiento',
    'col_quantity'     => 'Cantidad',
    'col_status'       => 'Estado',
    'col_created_by'   => 'Registrado por',
    'col_created_at'   => 'Fecha Ingreso',

    // Badges de estado
    'status_valid'    => 'Vigente',
    'status_expiring' => 'Por Vencer',
    'status_expired'  => 'Vencido',

    // Filtros
    'filter_product'    => 'Filtrar por producto',
    'filter_lot'        => 'Filtrar por lote',
    'filter_status'     => 'Todos los estados',
    'filter_date_from'  => 'Vencimiento desde',
    'filter_date_to'    => 'Vencimiento hasta',

    // Resumen de confirmación
    'confirm_title'   => 'Confirmar Ingreso de Inventario',
    'confirm_message' => 'Revise los datos antes de guardar. Esta acción sumará la cantidad al stock actual.',
    'confirm_save'    => 'Confirmar y Guardar',

    // Mensajes
    'created_success'       => 'Ingreso de inventario registrado exitosamente.',
    'lot_found'             => 'Lote existente encontrado. Datos precargados.',
    'lot_new'               => 'Número de lote nuevo.',
    'no_entries_to_save'    => 'No hay filas con datos para guardar. Complete al menos un SKU.',

    // Sección detalle
    'lot_info'         => 'Información del Lote',
    'entries_history'  => 'Historial de Ingresos del Lote',
    'detail_view'      => 'Ver Detalle',
];
