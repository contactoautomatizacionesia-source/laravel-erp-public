<?php

return [
    // Menu
    'menu_inventory_entry' => 'Inventory Entries',

    // General titles
    'inventory_entry_management' => 'Inventory Entry Management',
    'new_entry'                  => 'New Entry',
    'entry_detail'               => 'Entry Detail',

    // Form fields
    'product'          => 'Product',
    'product_hint'     => 'Search product by name or SKU',
    'variant'          => 'Variant / SKU',
    'variant_hint'     => 'Select variant',
    'lot_number'       => 'Lot Number',
    'lot_number_hint'  => 'Enter or search a lot number',
    'manufacture_date' => 'Manufacture Date',
    'expiration_date'  => 'Expiration Date',
    'quantity'         => 'Quantity',
    'location'         => 'Warehouse Location',
    'location_default' => 'Main',
    'supplier'         => 'Supplier / Lot Origin',
    'unit_cost'        => 'Unit Cost Price',
    'unit_cost_hint'   => 'Optional — for reference only',
    'notes'            => 'Notes / Observations',

    // Table columns
    'col_product'      => 'Product',
    'col_sku'          => 'SKU / Variant',
    'col_lot'          => 'Lot',
    'col_manufacture'  => 'Mfg. Date',
    'col_expiration'   => 'Exp. Date',
    'col_quantity'     => 'Quantity',
    'col_status'       => 'Status',
    'col_created_by'   => 'Registered by',
    'col_created_at'   => 'Entry Date',

    // Status badges
    'status_valid'    => 'Valid',
    'status_expiring' => 'Expiring Soon',
    'status_expired'  => 'Expired',

    // Filters
    'filter_product'    => 'Filter by product',
    'filter_lot'        => 'Filter by lot',
    'filter_status'     => 'All statuses',
    'filter_date_from'  => 'Expiration from',
    'filter_date_to'    => 'Expiration to',

    // Confirmation summary
    'confirm_title'   => 'Confirm Inventory Entry',
    'confirm_message' => 'Review the data before saving. This action will add the quantity to current stock.',
    'confirm_save'    => 'Confirm & Save',

    // Messages
    'created_success'       => 'Inventory entry successfully registered.',
    'lot_found'             => 'Existing lot found. Data preloaded.',
    'lot_new'               => 'New lot number.',
    'no_entries_to_save'    => 'No rows with data to save. Fill at least one SKU.',

    // Detail section
    'lot_info'         => 'Lot Information',
    'entries_history'  => 'Lot Entry History',
    'detail_view'      => 'View Detail',
];
