<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInventoryEntryTables extends Migration
{
    public function up()
    {
        // Tabla de lotes
        Schema::create('product_lots', function (Blueprint $table) {
            $table->id();
            $table->string('lot_number')->unique();
            $table->date('manufacture_date')->nullable();
            $table->date('expiration_date')->nullable();
            $table->string('supplier')->nullable();
            $table->text('notes')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();

            $table->index('lot_number');
            $table->index('expiration_date');
        });

        // Tabla de ingresos de inventario (historial)
        Schema::create('product_inventory_entries', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('lot_id');
            $table->unsignedBigInteger('product_sku_id');
            $table->decimal('quantity', 16, 2);
            $table->decimal('unit_cost', 16, 2)->nullable();
            $table->string('warehouse_location')->default('Principal');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();

            $table->foreign('lot_id')->references('id')->on('product_lots');
            $table->foreign('product_sku_id')->references('id')->on('product_sku');

            $table->index('lot_id');
            $table->index('product_sku_id');
            $table->index(['lot_id', 'product_sku_id']);
        });

        // Menú
        $parentMenu = DB::table('backendmenus')->where('name', 'product.product_manage')->first();
        if (!$parentMenu) {
            throw new \LogicException('Parent menu "product.product_manage" not found. Cannot register InventoryEntry menu.');
        }

        $menuId = DB::table('backendmenus')->insertGetId([
            'name'       => 'inventoryentry::inventory.menu_inventory_entry',
            'icon'       => 'ti-package',
            'parent_id'  => $parentMenu->id,
            'is_admin'   => 1,
            'is_seller'  => 0,
            'route'      => 'inventory_entry.index',
            'position'   => 57,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Asignar menú a SuperAdmin (user_id=1) y Admin (user_id=2) igual que InventoryCount
        $superAdminUsers = DB::table('users')
            ->whereIn('role_id', [1, 2])
            ->pluck('id');

        foreach ($superAdminUsers as $userId) {
            DB::table('backendmenu_users')->insert([
                'backendmenu_id' => $menuId,
                'user_id'        => $userId,
            ]);
        }

        // Permiso padre
        $permParentId = 800;
        DB::table('permissions')->insert([
            'id'          => $permParentId,
            'module_id'   => 58,
            'parent_id'   => null,
            'name'        => 'Inventory Entry',
            'translation' => 'inventoryentry::inventory.menu_inventory_entry',
            'route'       => 'inventory_entry.index',
            'status'      => 1,
            'created_by'  => 1,
            'updated_by'  => 1,
            'type'        => 1,
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);

        // Permisos hijos
        DB::table('permissions')->insert([
            [
                'id'          => 801,
                'module_id'   => 58,
                'parent_id'   => $permParentId,
                'name'        => 'Inventory Entries List',
                'translation' => 'inventoryentry::inventory.inventory_entry_management',
                'route'       => 'inventory_entry.index',
                'status'      => 1,
                'created_by'  => 1,
                'updated_by'  => 1,
                'type'        => 1,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
            [
                'id'          => 802,
                'module_id'   => 58,
                'parent_id'   => $permParentId,
                'name'        => 'Create Inventory Entry',
                'translation' => 'inventoryentry::inventory.new_entry',
                'route'       => 'inventory_entry.create',
                'status'      => 1,
                'created_by'  => 1,
                'updated_by'  => 1,
                'type'        => 1,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
            [
                'id'          => 803,
                'module_id'   => 58,
                'parent_id'   => $permParentId,
                'name'        => 'View Inventory Entry Detail',
                'translation' => 'inventoryentry::inventory.entry_detail',
                'route'       => 'inventory_entry.detail',
                'status'      => 1,
                'created_by'  => 1,
                'updated_by'  => 1,
                'type'        => 1,
                'created_at'  => now(),
                'updated_at'  => now(),
            ],
        ]);
    }

    public function down()
    {
        Schema::dropIfExists('product_inventory_entries');
        Schema::dropIfExists('product_lots');

        DB::table('permissions')->whereIn('id', [800, 801, 802, 803])->delete();

        $menu = DB::table('backendmenus')
            ->where('name', 'inventoryentry::inventory.menu_inventory_entry')
            ->first();

        if ($menu) {
            DB::table('backendmenu_users')->where('backendmenu_id', $menu->id)->delete();
            DB::table('backendmenus')->where('id', $menu->id)->delete();
        }
    }
}
