<?php

namespace Modules\InventoryEntry\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Modules\InventoryEntry\Entities\ProductLot;
use Modules\InventoryEntry\Entities\InventoryEntry;
use Modules\Product\Entities\ProductSku;
use Modules\Seller\Entities\SellerProductSKU;

class InventoryEntryService
{
    /**
     * Crea uno o varios ingresos de inventario en una sola transacción.
     * Cada item en $entries puede tener su propio lote (firstOrCreate por lot_number).
     *
     * @param array $entries  Array de ítems validados (entries.*)
     * @return InventoryEntry[]
     */
    public function createMany(array $entries): array
    {
        return DB::transaction(function () use ($entries) {
            $userId  = Auth::id();
            $created = [];

            foreach ($entries as $data) {
                // 1. Crear o recuperar el lote por lot_number
                $lot = ProductLot::firstOrCreate(
                    ['lot_number' => $data['lot_number']],
                    [
                        'manufacture_date' => $data['manufacture_date'] ?? null,
                        'expiration_date'  => $data['expiration_date'] ?? null,
                        'supplier'         => $data['supplier'] ?? null,
                        'notes'            => $data['notes'] ?? null,
                        'created_by'       => $userId,
                    ]
                );

                // 2. Registrar el ingreso en el historial
                $entry = InventoryEntry::create([
                    'lot_id'             => $lot->id,
                    'product_sku_id'     => $data['product_sku_id'],
                    'quantity'           => $data['quantity'],
                    'unit_cost'          => $data['unit_cost'] ?? null,
                    'warehouse_location' => $data['warehouse_location'] ?? __('inventoryentry::inventory.location_default'),
                    'created_by'         => $userId,
                ]);

                // 3. Sumar stock en product_sku (bodega principal administrativa)
                ProductSku::where('id', $data['product_sku_id'])
                    ->increment('product_stock', $data['quantity']);

                // 4. Sumar stock en seller_product_s_k_us (bodega principal — user_id=1)
                SellerProductSKU::where('product_sku_id', $data['product_sku_id'])
                    ->where('user_id', 1)
                    ->increment('product_stock', $data['quantity']);

                $created[] = $entry;
            }

            return $created;
        });
    }

    /**
     * Retorna el estado badge de un lote para la vista.
     * Retorna array con [key, label, badge_class]
     */
    public function getLotStatusBadge(ProductLot $lot): array
    {
        $status = $lot->status;

        $map = [
            'vigente'    => ['key' => 'vigente',    'label' => __('inventoryentry::inventory.status_valid'),    'class' => 'badge_1'],
            'por_vencer' => ['key' => 'por_vencer', 'label' => __('inventoryentry::inventory.status_expiring'), 'class' => 'badge_3'],
            'vencido'    => ['key' => 'vencido',    'label' => __('inventoryentry::inventory.status_expired'),  'class' => 'badge_2'],
        ];

        return $map[$status] ?? $map['vigente'];
    }
}
