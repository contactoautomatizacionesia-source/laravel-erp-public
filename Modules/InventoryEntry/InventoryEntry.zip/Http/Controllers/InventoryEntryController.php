<?php

namespace Modules\InventoryEntry\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\InventoryEntry\Entities\InventoryEntry;
use Modules\InventoryEntry\Entities\ProductLot;
use Modules\InventoryEntry\Http\Requests\StoreInventoryEntryRequest;
use Modules\InventoryEntry\Services\InventoryEntryService;
use Modules\Product\Entities\Product;
use Modules\Product\Entities\ProductSku;
use Modules\UserActivityLog\Traits\LogActivity;
use Yajra\DataTables\Facades\DataTables;

class InventoryEntryController extends Controller
{
    public function __construct(protected InventoryEntryService $service) {}

    // ─── Vistas ───────────────────────────────────────────────────

    public function index()
    {
        return view('inventoryentry::inventory.index');
    }

    public function create()
    {
        return view('inventoryentry::inventory.create');
    }

    // ─── DataTable ────────────────────────────────────────────────

    public function getData(Request $request)
    {
        if (!$request->ajax()) {
            return response()->json(['error' => 'Bad Request'], 400);
        }

        $query = InventoryEntry::with(['lot', 'productSku.product', 'productSku.product_variations', 'createdBy'])
            ->select('product_inventory_entries.*');

        // Filtro por producto (nombre o SKU)
        if ($request->filled('product_filter')) {
            $search = $request->product_filter;
            $query->whereHas('productSku.product', function ($q) use ($search) {
                $q->where('product_name', 'like', "%{$search}%");
            })->orWhereHas('productSku', function ($q) use ($search) {
                $q->where('sku', 'like', "%{$search}%");
            });
        }

        // Filtro por número de lote
        if ($request->filled('lot_filter')) {
            $query->whereHas('lot', function ($q) use ($request) {
                $q->where('lot_number', 'like', '%' . $request->lot_filter . '%');
            });
        }

        // Filtro por estado del lote
        if ($request->filled('status_filter')) {
            $today = Carbon::today();
            if ($request->status_filter === 'vigente') {
                $query->whereHas('lot', fn($q) => $q->where(function ($q2) use ($today) {
                    $q2->whereNull('expiration_date')->orWhere('expiration_date', '>', $today->copy()->addDays(30));
                }));
            } elseif ($request->status_filter === 'por_vencer') {
                $query->whereHas('lot', fn($q) => $q->whereBetween('expiration_date', [$today, $today->copy()->addDays(30)]));
            } elseif ($request->status_filter === 'vencido') {
                $query->whereHas('lot', fn($q) => $q->where('expiration_date', '<', $today));
            }
        }

        // Filtro por rango de fecha de vencimiento
        if ($request->filled('exp_from')) {
            $query->whereHas('lot', fn($q) => $q->where('expiration_date', '>=', $request->exp_from));
        }
        if ($request->filled('exp_to')) {
            $query->whereHas('lot', fn($q) => $q->where('expiration_date', '<=', $request->exp_to));
        }

        return DataTables::of($query)
            ->addIndexColumn()
            ->addColumn('product_name', function ($row) {
                if (!$row->productSku?->product) {
                    return 'N/A';
                }
                $name = $row->productSku->product->product_name;
                $decoded = json_decode($name, true);
                return is_array($decoded) ? ($decoded[app()->getLocale()] ?? reset($decoded) ?? $name) : $name;
            })
            ->addColumn('sku_variant', function ($row) {
                if (!$row->productSku) {
                    return 'N/A';
                }
                $sku = $row->productSku->sku ?? '';
                $track = $row->productSku->track_sku ?? '';
                return $track ? "<span class=\"badge_5\">{$track}</span>" : ($sku ?: 'N/A');
            })
            ->addColumn('lot_number', fn($row) => $row->lot?->lot_number ?? 'N/A')
            ->addColumn('manufacture_date', function ($row) {
                $date = $row->lot?->manufacture_date;
                if (!$date) {
                    return '—';
                }
                return '<span title="' . $date->format('Y-m-d') . '">' . $date->diffForHumans() . '</span>';
            })
            ->addColumn('expiration_date', function ($row) {
                $date = $row->lot?->expiration_date;
                if (!$date) {
                    return '—';
                }
                return '<span title="' . $date->format('Y-m-d') . '">' . $date->diffForHumans() . '</span>';
            })
            ->addColumn('status_badge', function ($row) {
                if (!$row->lot) {
                    return '';
                }
                $badge = $this->service->getLotStatusBadge($row->lot);
                return '<span class="' . $badge['class'] . '">' . $badge['label'] . '</span>';
            })
            ->addColumn('created_by_name', function ($row) {
                $user = $row->createdBy;
                return $user ? trim($user->first_name . ' ' . $user->last_name) : 'N/A';
            })
            ->addColumn('entry_date', function ($row) {
                return '<span title="' . $row->created_at->format('Y-m-d H:i') . '">' . $row->created_at->diffForHumans() . '</span>';
            })
            ->addColumn('actions', function ($row) {
                return view('inventoryentry::inventory.partials.entry_actions', ['row' => $row])->render();
            })
            ->rawColumns(['sku_variant', 'manufacture_date', 'expiration_date', 'status_badge', 'entry_date', 'actions'])
            ->make(true);
    }

    // ─── Guardar ingreso ──────────────────────────────────────────

    public function store(StoreInventoryEntryRequest $request)
    {
        try {
            $entries = $this->service->createMany($request->validated()['entries']);

            $lots = collect($entries)->map(fn($e) => $e->lot->lot_number ?? '?')->unique()->implode(', ');
            LogActivity::successLog(__('inventoryentry::inventory.created_success') . " — {$lots} ({" . count($entries) . "} registros)");

            return response()->json([
                'success' => true,
                'message' => __('inventoryentry::inventory.created_success'),
            ]);
        } catch (\Exception $e) {
            LogActivity::errorLog('InventoryEntry store error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    // ─── Detalle ──────────────────────────────────────────────────

    public function detail($id)
    {
        $entry = InventoryEntry::with([
            'lot.entries.productSku.product',
            'lot.entries.createdBy',
            'productSku.product',
            'productSku.product_variations.attribute',
            'productSku.product_variations.attribute_value',
            'createdBy',
        ])->findOrFail($id);

        $statusBadge = $this->service->getLotStatusBadge($entry->lot);

        return view('inventoryentry::inventory.partials.entry_detail_modal', compact('entry', 'statusBadge'))->render();
    }

    // ─── AJAX helpers ─────────────────────────────────────────────

    public function searchProducts(Request $request)
    {
        $search = $request->get('q', '');

        $products = Product::with('skus')
            ->where('status', 1)
            ->where(function ($q) use ($search) {
                $q->where('product_name', 'like', "%{$search}%")
                  ->orWhereHas('skus', fn($q2) => $q2->where('sku', 'like', "%{$search}%"));
            })
            ->select('id', 'product_name', 'product_type')
            ->limit(15)
            ->get()
            ->map(function ($product) {
                $name = $product->product_name;
                $decoded = json_decode($name, true);
                $displayName = is_array($decoded) ? ($decoded[app()->getLocale()] ?? reset($decoded) ?? $name) : $name;

                return [
                    'id'           => $product->id,
                    'text'         => $displayName,
                    'product_type' => $product->product_type,
                ];
            });

        return response()->json(['results' => $products]);
    }

    public function getProductSkus($productId)
    {
        $skus = ProductSku::where('product_id', $productId)
            ->where('status', 1)
            ->get()
            ->map(function ($sku) {
                $label = $sku->track_sku ?: ($sku->sku ?: "SKU #{$sku->id}");
                return [
                    'id'           => $sku->id,
                    'text'         => $label,
                    'product_stock'=> $sku->product_stock,
                ];
            });

        return response()->json(['skus' => $skus]);
    }

    public function findLot(Request $request)
    {
        $lot = ProductLot::where('lot_number', $request->get('lot_number'))->first();

        if (!$lot) {
            return response()->json(['found' => false]);
        }

        return response()->json([
            'found'            => true,
            'manufacture_date' => $lot->manufacture_date?->format('Y-m-d'),
            'expiration_date'  => $lot->expiration_date?->format('Y-m-d'),
            'supplier'         => $lot->supplier,
            'notes'            => $lot->notes,
        ]);
    }
}
