<?php

return [
    'name' => 'InventoryEntry'
];
