<?php

namespace Modules\InventoryEntry\Entities;

use Illuminate\Database\Eloquent\Model;

class InventoryEntry extends Model
{
    protected $table = 'product_inventory_entries';

    protected $guarded = ['id'];

    protected $casts = [
        'quantity'  => 'decimal:2',
        'unit_cost' => 'decimal:2',
    ];

    // ─── Relaciones ───────────────────────────────────────────────

    public function lot()
    {
        return $this->belongsTo(ProductLot::class, 'lot_id');
    }

    public function productSku()
    {
        return $this->belongsTo(\Modules\Product\Entities\ProductSku::class, 'product_sku_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }
}
